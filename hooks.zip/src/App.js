import React from "react";
import GithubUsers from "./components/customHook/GithubUsers";

const App = () => {
  return (
    <div>
      <GithubUsers />
    </div>
  );
};

export default App;
